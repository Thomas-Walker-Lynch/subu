
def network_toggle(subu_id: str, state: str):
  sid = int(subu_id.split("_")[1])
  with closing(_db()) as db:
    ns, wid = db.execute("SELECT netns,wg_id FROM subu WHERE id=?", (sid,)).fetchone()
  # always make sure lo up on 'up'
  if state == "up":
    run(["ip", "netns", "exec", ns, "ip", "link", "set", "lo", "up"], check=False)
  if wid is not None:
    ifname = f"subu_{wid}"
    run(["ip", "-n", ns, "link", "set", "dev", ifname, state], check=False)
  with closing(_db()) as db:
    db.execute("UPDATE subu SET network_state=? WHERE id=?", (state, sid))
    db.commit()
  print(f"{subu_id}: network {state}")

