# ------------- Subu ops -------------
def create_subu(owner: str, name: str) -> str:
  with closing(_db()) as db:
    c = db.cursor()
    subu_netns = f"ns-subu_tmp"  # temp; we rename after ID known
    c.execute("INSERT INTO subu (owner, name, netns) VALUES (?, ?, ?)",
              (owner, name, subu_netns))
    sid = c.lastrowid
    netns = f"ns-subu_{sid}"
    c.execute("UPDATE subu SET netns=? WHERE id=?", (netns, sid))
    db.commit()

  # create netns
  run(["ip", "netns", "add", netns])
  run(["ip", "-n", netns, "link", "set", "lo", "down"])
  print(f"Created subu_{sid} ({owner}:{name}) with netns {netns}")
  return f"subu_{sid}"

def list_subu():
  with closing(_db()) as db:
    for row in db.execute("SELECT id, owner, name, netns, lo_state, wg_id, network_state FROM subu"):
      print(row)

def info_subu(subu_id: str):
  sid = int(subu_id.split("_")[1])
  with closing(_db()) as db:
    row = db.execute("SELECT * FROM subu WHERE id=?", (sid,)).fetchone()
    if not row:
      print("not found"); return
    print(row)
    wg = db.execute("SELECT wg_id FROM subu WHERE id=?", (sid,)).fetchone()[0]
    if wg is not None:
      wrow = db.execute("SELECT * FROM wg WHERE id=?", (wg,)).fetchone()
      print("WG:", wrow)
    opts = db.execute("SELECT name,value FROM options WHERE subu_id=?", (sid,)).fetchall()
    print("Options:", opts)

def lo_toggle(subu_id: str, state: str):
  sid = int(subu_id.split("_")[1])
  with closing(_db()) as db:
    ns = db.execute("SELECT netns FROM subu WHERE id=?", (sid,)).fetchone()
    if not ns: raise ValueError("subu not found")
    ns = ns[0]
    run(["ip", "netns", "exec", ns, "ip", "link", "set", "lo", state])
    db.execute("UPDATE subu SET lo_state=? WHERE id=?", (state, sid))
    db.commit()
  print(f"{subu_id}: lo {state}")

